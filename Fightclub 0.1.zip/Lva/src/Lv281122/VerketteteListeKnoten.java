package Lv281122;

public class VerketteteListeKnoten {

    int inhalt;
    VerketteteListeKnoten naechsterKnoten;
}
