package Zoo;

public class Horse extends Animal {

}
