package Zoo;

public class Katzenhalter {
    public Cat[] meineKatzen;

    public Katzenhalter(){

    }
    public Katzenhalter(Cat[] katzenrudel){
        this.meineKatzen = katzenrudel;
    }
}
