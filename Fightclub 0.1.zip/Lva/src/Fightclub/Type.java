package Fightclub;

public enum Type {
    STEIN, PAPIER, SCHERE
}
