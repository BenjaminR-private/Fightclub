package Fightclub;public class Character {
}
