package Fightclub;

import java.util.Scanner;

public class Fight {

    Player player1;
    Player player2;

    public void printDmg(Player playerAtt, Player playerDef, int arrayIndex, double random) {
        System.out.printf("%S deals %2.1f Damage with a %S to %S, reducing %S's Health from %2.1f to %2.1f\n",
                playerAtt.getName(),
                (playerAtt.getActiveWeapons()[arrayIndex].getBaseDamage() * random), playerAtt.getActiveWeapons()[arrayIndex].getwName(),
                playerDef.getName(), playerDef.getName(), playerDef.getHealth(),
                (playerDef.getHealth() - (playerAtt.getActiveWeapons()[arrayIndex].getBaseDamage() * random)));
    }
    /// OLD VERSION
    //                System.out.printf("%S deals %2.1f Damage to %S, reducing %S's Health from %2.1f to %2.1f\n",
//                        player1.getName(),
//                        (pl1Wpns[i].getBaseDamage() * (Math.random() + 1)),
//                        player2.getName(), player2.getName(), player2.getHealth(),
//                        (player2.getHealth() - (pl1Wpns[i].getBaseDamage() * (Math.random() + 1))));

    //                System.out.printf("%S deals %2.1f Damage to %S, reducing %S's Health from %2.1f to %2.1f\n",
//                        player2.getName(),
//                        (pl2Wpns[i].getBaseDamage() * (Math.random() + 1)),
//                        player1.getName(), player1.getName(), player1.getHealth(),
//                        (player1.getHealth() - (pl2Wpns[i].getBaseDamage() * (Math.random() + 1))));

    public void printNoDmg(Player playerAtt, Player playerDef, int arrayIndex) {
        System.out.printf("%S doesn't deal any Dmg to %S, because a %S's %S doesn't do shit against %S's %S\n",
                playerAtt.getName(), playerDef.getName(),
                playerAtt.getName(), playerAtt.getActiveWeapons()[arrayIndex].getwName(),
                playerDef.getName(), playerDef.getActiveWeapons()[arrayIndex].getwName());
    }

    public void chooseWeapons(Player player1, Player player2) {
        player1.showAllWeapons(player1);
        player1.setActiveWeapons(player1.setActiveWeaponArray());
        player1.showAActiveWeapons(player1.getActiveWeapons());
        if (!player2.isAi()) {
            for (int i = 0; i < 25; i++) {
                System.out.println();
            }
            player2.showAllWeapons(player2);
            player2.setActiveWeapons(player2.setActiveWeaponArray());
            player2.showAActiveWeapons(player2.getActiveWeapons());
        }
    }

    public Fight(Player player1, Player player2) {
        this.player1 = player1;
        this.player2 = player2;
    }

    public Player fight(Player player1, Player player2) throws InterruptedException {
        Scanner scan = new Scanner(System.in);
        while (player1.getHealth() > 0 && player2.getHealth() > 0) {
            chooseWeapons(player1, player2);
            Weapon[] pl1Wpns = player1.getActiveWeapons();
            Weapon[] pl2Wpns = player2.getActiveWeapons();
            for (int i = 0; i < 3; i++) {
                double random = Math.random() + 1;
                //Same Weapons
                if (pl1Wpns[i].getType() == pl2Wpns[i].getType()) {
                    printDmg(player1, player2, i, random);
                    player1.setHealth(player1.getHealth() - (pl2Wpns[i].getBaseDamage() * random));
                    random = Math.random() + 1;
                    printDmg(player2, player1, i, random);
                    player2.setHealth(player2.getHealth() - (pl1Wpns[i].getBaseDamage() * random));
                } else {
                    // Players use different Weapons
                    if ((pl1Wpns[i].getType() == Type.STEIN && pl2Wpns[i].getType() == Type.SCHERE)) {
                        //TODO
                        //SCHERE doesn't deal dmg against STEIN, so only player 1 deals dmg
                        printDmg(player1, player2, i, random);
                        player2.setHealth(player2.getHealth() - (pl1Wpns[i].getBaseDamage() * random));
                        printNoDmg(player2, player1, i);
                    } else if (pl1Wpns[i].getType() == Type.STEIN && pl2Wpns[i].getType() == Type.PAPIER) {
                        //TODO
                        //STEIN doesn't deal dmg against PAPIER, so only player 2 deals dmg
                        printDmg(player2, player1, i, random);
                        player1.setHealth(player1.getHealth() - (pl2Wpns[i].getBaseDamage() * random));
                        printNoDmg(player1, player2, i);
                    } else if (pl1Wpns[i].getType() == Type.SCHERE && pl2Wpns[i].getType() == Type.STEIN) {
                        //TODO
                        //SCHERE doesn't deal dmg against STEIN, so only player 2 deals dmg
                        printDmg(player2, player1, i, random);
                        player1.setHealth(player1.getHealth() - (pl2Wpns[i].getBaseDamage() * random));
                        printNoDmg(player1, player2, i);
                    } else if (pl1Wpns[i].getType() == Type.SCHERE && pl2Wpns[i].getType() == Type.PAPIER) {
                        //TODO
                        //PAPIER doesn't deal dmg against SCHERE, so only player 1 deals dmg
                        printDmg(player1, player2, i, random);
                        player2.setHealth(player2.getHealth() - (pl1Wpns[i].getBaseDamage() * random));
                        printNoDmg(player2, player1, i);
                    } else if (pl1Wpns[i].getType() == Type.PAPIER && pl2Wpns[i].getType() == Type.STEIN) {
                        //TODO
                        //STEIN doesn't deal dmg against PAPIER, so only player 1 deals dmg
                        printDmg(player1, player2, i, random);
                        player2.setHealth(player2.getHealth() - (pl1Wpns[i].getBaseDamage() * random));
                        printNoDmg(player2, player1, i);
                    } else if (pl1Wpns[i].getType() == Type.PAPIER && pl2Wpns[i].getType() == Type.SCHERE) {
                        //TODO
                        //PAPIER doesn't deal dmg against SCHERE, so only player 2 deals dmg
                        printDmg(player2, player1, i, random);
                        player1.setHealth(player1.getHealth() - (pl2Wpns[i].getBaseDamage() * random));
                        printNoDmg(player1, player2, i);
                    }
                }
                //TODO
                //Test if one of the players died after an attack
//            if(player1.getHealth() || player2)
                if (player1.getHealth() <= 0 && player2.getHealth() <= 0) {
                    return null;
                } else if (player1.getHealth() <= 0) {
                    System.out.printf("%S has %2.2f Health and died", player1.getName(), player1.getHealth());
                    return player2;
                } else if (player2.getHealth() <= 0) {
                    System.out.printf("%S has %2.2f Health and died", player2.getName(), player2.getHealth());
                    return player1;
                }
                Thread.sleep(2500);
            }
            //Show Health stats
            System.out.printf("%s has %2.2f Health left   ||   %s has %2.2f Health left \nPrepare for the next round..." +
                            "\n\n\n",
                    player1.getName(), player1.getHealth(), player2.getName(), player2.getHealth());
            boolean cont = false;
            while (!cont) {
                System.out.println("Press 'y' to choose Weapons or 'n' to flee from battle");
                String input = scan.nextLine();
                if (input.equalsIgnoreCase("n")) {
                    return player2;
                } else if (input.equalsIgnoreCase("y")) {
                    cont = true;
                    countdown(5);
                }
            }
        }
        scan.close();
        return player1;
    }

    //TODO
    public Player checkHealth(Player player1, Player player2) {
        Player winner = null;
        if (player1.getHealth() <= 0 && player2.getHealth() <= 0) {
            return null;
        } else if (player1.getHealth() <= 0) {
            System.out.printf("%S has %2.2f Health and died", player1.getName(), player1.getHealth());
            return player2;
        } else if (player2.getHealth() <= 0) {
            System.out.printf("%S has %2.2f Health and died", player2.getName(), player2.getHealth());
            return player1;
        }
        return winner;
    }

    private void countdown(int sekunden) throws InterruptedException {
        for (int i = 0; i < sekunden; i++) {
            System.out.println(sekunden - i + "\n\n\n");
            Thread.sleep(1000);
        }
        System.out.println("\n\n\nG");
    }
}
