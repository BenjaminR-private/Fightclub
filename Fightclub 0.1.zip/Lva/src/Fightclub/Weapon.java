package Fightclub;

public class Weapon extends InvObject{

    private String wName;
    private int baseDamage;
    private double wDurability;
    private double dmgModifier;
//    private Type type;


    public Weapon(String wName, int baseDamage, double wDurability, double dmgModifier, Type type) {
        super();
        this.wName = wName;
        this.baseDamage = baseDamage;
        this.wDurability = wDurability;
        this.dmgModifier = dmgModifier;
        this.type = type;
    }

    public String getwName() {
        return wName;
    }

    public void setwName(String wName) {
        this.wName = wName;
    }

    public int getBaseDamage() {
        return baseDamage;
    }

    public void setBaseDamage(int baseDamage) {
        this.baseDamage = baseDamage;
    }

    public double getwDurability() {
        return wDurability;
    }

    public void setwDurability(double wDurability) {
        this.wDurability = wDurability;
    }

    public double getDmgModifier() {
        return dmgModifier;
    }

    public void setDmgModifier(double dmgModifier) {
        this.dmgModifier = dmgModifier;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }
}
