package Fightclub;

import java.util.Scanner;

public class Main {
    static Scanner scan = new Scanner(System.in);

    public static void main(String[] args) throws InterruptedException {

        Player player1 = new Player("player1", 100,false,null, new Weapon[3], 0.0d);
        Player player2 = new Player("player2", 100,false,null, new Weapon[3], 0.0d);

        Weapon basicSword = new Sword("Basic Sword", 10, Double.MAX_VALUE, 1.0d, Type.STEIN);
        Weapon basicBow = new Bow("Basic Bow", 10, Double.MAX_VALUE, 1.0d, Type.PAPIER);
        Weapon basicSpear = new Spear("Basic Spear", 10, Double.MAX_VALUE, 1.0d, Type.SCHERE);

        Weapon[] basicWeapons = {basicSpear, basicBow, basicSword};

        //Name Players

        System.out.println("Player 1 name: ");
        player1.setName(scan.nextLine());
        System.out.println("Player 1 is named " + player1.getName());

        System.out.println("Player 2 name: ");
        player2.setName(scan.nextLine());
        System.out.println("Player 2 is named " + player2.getName());

        player1.setAllWeapons(basicWeapons);
        player2.setAllWeapons(basicWeapons);

//        System.out.println(player1.getName() + " chooses Weapons");
//        player1.showAllWeapons(player1);
//        player1.setActiveWeapons(player1.setActiveWeaponArray());
//        player1.showAActiveWeapons(player1.getActiveWeapons());
//
//        System.out.println(player2.getName() + " chooses Weapons");
//        player2.showAllWeapons(player2);
//        player2.setActiveWeapons(player2.setActiveWeaponArray());
//        player2.showAActiveWeapons(player2.getActiveWeapons());

        Fight fight1 = new Fight(player1, player2);
        fight1.fight(player1, player2);


        //// STuff
//        Weapon test = player1.getActiveWeapons()[1];
//        System.out.println(test.getClass());
//        if(test.getClass().toString().equals("Fightclub.Spear"));
//        System.out.println("stimmt");

//        player1.putWeoponInArray(basicBow);
//        player1.putWeoponInArray(basicSword);
//        player1.putWeoponInArray(basicSpear);
//
//        player2.putWeoponInArray(basicBow);
//        player2.putWeoponInArray(basicSword);
//        player2.putWeoponInArray(basicSpear);



    }
}
