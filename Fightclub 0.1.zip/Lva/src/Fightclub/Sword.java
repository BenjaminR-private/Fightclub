package Fightclub;

import static Fightclub.Type.STEIN;

public class Sword extends Weapon{
//    private final Type type;

    public Sword(String wName, int baseDamage, double wDurability, double dmgModifier, Type type) {
        super(wName, baseDamage, wDurability, dmgModifier, type);
//        this.type = type;
    }
//    public Type getType() {
//        return type;
//    }
}
