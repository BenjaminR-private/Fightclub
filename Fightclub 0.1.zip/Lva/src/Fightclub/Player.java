package Fightclub;

import java.util.Scanner;

public class Player {

    private String name;
    private double health;
    private boolean ai;
    private Weapon[] allWeapons;
    private Weapon[] activeWeapons;
    private double coins;

    public Player(String name, double health, boolean ai, Weapon[] allWeapons, Weapon[] activeWeapons, double coins) {
        this.name = name;
        this.health = health;
        this.ai = ai;
        this.allWeapons = allWeapons;
        this.activeWeapons = activeWeapons;
        this.coins = coins;
    }

    //TODO
    public Weapon buyWeapon(double price) {
        return null;
    }

    //TODO
    public void destroyWeapon() {

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getHealth() {
        return health;
    }

    public void setHealth(double health) {
        this.health = health;
    }

    public boolean isAi() {
        return ai;
    }

    public void setAi(boolean ai) {
        this.ai = ai;
    }

    public Weapon[] getAllWeapons() {
        return allWeapons;
    }

    public void setAllWeapons(Weapon[] allWeapons) {
        this.allWeapons = allWeapons;
    }

    public Weapon[] getActiveWeapons() {
        return activeWeapons;
    }

    public void setActiveWeapons(Weapon[] activeWeapons) {
        this.activeWeapons = activeWeapons;
    }

    public Weapon[] setActiveWeaponArray() {
        Weapon[] activeWeapons = new Weapon[3];
        Scanner scan = new Scanner(System.in);
        int choice = -1;
        for (int i = 0; i < activeWeapons.length; i++) {
            do{
                //TODO
                //already< choosen weapons should not be chooseable
                System.out.printf("%S: Choose Weapon %d of %d from  your Inventory by typing a number between 0 and %d\n",
                        this.getName(), i, activeWeapons.length, (this.getAllWeapons().length-1));
                choice = scan.nextInt();
                if(choice > this.getAllWeapons().length-1 || choice < 0){
                    System.out.println("Invalid choice");
                }
            }while(choice > this.getAllWeapons().length-1 || choice < 0);
            activeWeapons[i] = this.getAllWeapons()[choice];
        }
        return activeWeapons;
    }

    public Weapon[] setActiveWeaponArrayBkp() {
        Weapon[] activeWeapons = new Weapon[3];
        Scanner scan = new Scanner(System.in);
        for (int i = 0; i < activeWeapons.length; i++) {
            int choice = scan.nextInt();
            activeWeapons[i] = this.getAllWeapons()[choice];
        }
        return activeWeapons;
    }

    public double getCoins() {
        return coins;
    }

    public void setCoins(double coins) {
        this.coins = coins;
    }

    //TODO
    public void addHealth(int health) {

    }

    //TODO
    public void addCoin(int coins) {

    }

    //TODO
    public void addWeapon(Weapon weapon) {

    }

    //TODO
    public void putWeoponInArray() {
        Weapon[] allWeapons = this.getAllWeapons();


    }

    public void showAllWeapons(Player player) {
        for (int i = 0; i < player.getAllWeapons().length; i++) {
            System.out.printf("%2d : %15S \t\tDmg: %3d \n", i, player.getAllWeapons()[i].getwName(), player.getAllWeapons()[i].getBaseDamage());
        }
    }

    public void showAActiveWeapons(Weapon[] activeWeapons) {
        for (int i = 0; i < activeWeapons.length; i++) {
            System.out.printf("%2d : %15S \t\tDmg: %3d \n", i, activeWeapons[i].getwName(), activeWeapons[i].getBaseDamage());
        }
    }
}
