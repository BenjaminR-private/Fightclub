package Fightclub;

public class InvObject {
    protected Type type;

    public InvObject(Type type) {
    }
    public InvObject() {

    }
}
