package Fightclub;

import static Fightclub.Type.PAPIER;

public class Bow extends Weapon {
//    private final Type type;

    public Bow(String wName, int baseDamage, double wDurability, double dmgModifier, Type type) {
        super(wName, baseDamage, wDurability, dmgModifier, type);
//        this.type = type;
    }
}
