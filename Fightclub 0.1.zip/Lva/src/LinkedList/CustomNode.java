package LinkedList;

public class CustomNode {
    protected int data;
    protected CustomNode nextNode;
    public CustomNode(int data) {
        this.data = data;
        this.nextNode = null;
    }

    public CustomNode() {

    }
}
